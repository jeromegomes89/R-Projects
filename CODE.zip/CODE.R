library(geosphere)
library(reshape2)
library(dplyr)
library(data.table)


eNB <- read.csv(file.choose(),header = TRUE) # reading the data
str(eNB)
colnames(eNB)
LonLat <- cbind(eNB$JCPLON,eNB$JCPLAT) # vector matrix for analysis
rm(eNB)

eNBnOLsMatrix <- round(distm(LonLat),digits = 2)
rm(LonLat)

eNBnOLsMatrix1 <-as.data.frame(eNBnOLsMatrix)
rm(eNBnOLsMatrix)

rnames <- rownames(eNBnOLsMatrix1)
eNBnOLsMatrix2 <- as.data.frame(cbind(rnames,eNBnOLsMatrix1))
rm(eNBnOLsMatrix1)

eNBnOLsMatrix3 <- melt(eNBnOLsMatrix2, id=c("rnames"))
str(eNBnOLsMatrix3)
rm(eNBnOLsMatrix2)

eNBnOLsMatrix4 <- eNBnOLsMatrix3[order(eNBnOLsMatrix3$rnames,eNBnOLsMatrix3$value),]
rm(eNBnOLsMatrix3)
rm(rnames)

eNBnOLsMatrix5 <- subset(eNBnOLsMatrix4,eNBnOLsMatrix4$value >= 1)
rm(eNBnOLsMatrix4)


setDT(eNBnOLsMatrix5)[, rank := frank(value, ties.method = "dense"),
                      by = .(rnames)]

eNBnOLsMatrix6 <- subset(eNBnOLsMatrix5,eNBnOLsMatrix5$rank <= 10)
rm(eNBnOLsMatrix5)

getwd()
write.csv(eNBnOLsMatrix6,"ORS_IPCOLO&OWNDIST.csv")

rm(eNBnOLsMatrix6)
